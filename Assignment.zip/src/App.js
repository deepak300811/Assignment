import "./App.css"
import InputSub from "./components/InputSub"

function App() {
  return (
    <div className="App">
      <InputSub />
    </div>
  )
}

export default App
